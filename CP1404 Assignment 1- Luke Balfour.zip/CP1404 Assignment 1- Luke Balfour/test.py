MENU = """
List \t ---- L\n
Add \t ---- A\n
Mark Visited \t ---- M\n
Quit \t ---- Q\n
>>> 
"""
FILENAME = "places.csv"


def main():
    places = load_places(FILENAME)
    choice = input(MENU).upper()
    while choice != "Q":
        if choice == "L":
        # List function
        elif choice == "A":
        # Add function
        elif choice == "M":
        # Visit function
        else:
        # Invalid menu option print statement
        choice = input(MENU).upper()
    # save function


def list_places(places):
    pass


#     # LIST FUNCTION
# def listFunction(dataFile):
#
#     data = []
#     inputFile = open("visitList.txt", "r")
#
#     for information in dataFile:
#         print(dataFile)
#         parts = information.split(",")
#         print(parts)
#         print(information)
#         print("{} : {} : {} : {}".format(information, dataFile))
#         print("----------------")
#         inputFile.close()
#
#     # ADD FUNCTION
# def addFunction():
#     visitList = []
#     dataMark = 1
#     priority = int(input("Please enter the priority number: "))
#
#     for data in range(1, dataMark + 1):
#         name = str(input("Enter the location name: "))
#         country = str(input("Enter the location's country: "))
#         visited = " X "
#
#         visitList.append(name, country, priority, visited)
#
#     print("\nIncome Report\n-------------")
#     total = 0
#
#     for data in range(1, dataMark + 1):
#         data = visitList[dataMark - 1]
#         total += data
#         print("Priority {:2} - Income: ${:10.2f} Total: ${:10.2f}".format(name, country, priority))
#
#
#
#
#     userInput = str(input("Please select an option: "))
#
#     if userInput == "L":
#         listFunction()


main()


"""
TRASH CODE:

    # MAIN MENU FUNCTION
    def mainMenu():

        print("List \t ---- L\n"
        "Add \t ---- A\n"
        "Mark Visited \t ---- M\n"
        "Quit \t ---- Q\n")

        userInput = str(input("Please select an option: "))

        if userInput == "L":
            listFunction()
    runMenu = True
---------------------------------------------------------------------------
    while runMenu == True:
        mainMenu()



    print("\nIncome Report\n-------------")
    total = 0

    for data in range(1, dataMark + 1):
        data = FILENAME[dataMark - 1]
        total += data
        print("Priority {:2} - Income: ${:10.2f} Total: ${:10.2f}".format(name, country, priority))


"""