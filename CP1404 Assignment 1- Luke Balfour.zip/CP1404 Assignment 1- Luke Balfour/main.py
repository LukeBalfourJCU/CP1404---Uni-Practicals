"""
CORE PROGRAM

There are 4 options in the main menu. List, Add, Mark Visited, and Quit.
YOU MUST USE MANUAL ERROR CHECKING

LIST:
Prints the list of all places based on priority. Unvisited places must be marked with an '*'

ADD:
Prompts the user to input the place's name, country, and priority. Manual error checking required.
This data must be put into the memory. It will be saved to the CSV file on exit.

MARK VISITED:
Print list of places, but the user can choose an unvisited place to be changed to visited.
If no places are unvisited, print "No unvisited places".

QUIT:
Save all user data to the CSV file and end the program.

"""

MENU = """
L \t---- List places
A \t---- Add new place
M \t---- Mark a place as visited
Q \t---- Quit
>>> 
"""

FILENAME = "visitList.csv"
data = []

#LIST FUNCTION
def listFunction(data,FILENAME):

    data = []
    inputFile = open(FILENAME, "r")

    for information in inputFile:
        print("{}".format(information))

#ADD FUNCTION
def addFunction(data,FILENAME):

    dataMark = 1
    inputFile = open(FILENAME, "a")

    for data in range(1, dataMark + 1):

        name = str(input("Name: "))
        while name == "":
            print("Input cannot be blank")
            name = str(input("Name: "))

        country = str(input("Country: "))
        while country == "":
            print("Input cannot be blank")
            country = str(input("Country: "))

        try:
            priority = int(input("Priority: "))
            while priority == "":
                print("Invalid input; enter a valid number")
                priority = int(input("Priority: "))
        except:
            print("Invalid input; enter a valid number")

        visited = "*"
        compiler = (name, country, priority, visited)
        data = str(compiler)
        tempData = str(compiler)
        inputFile.write(str(compiler))
        return data



#MARK FUNCTION
def markFunction(data, FILENAME):

#    data = []
    inputFile = open(FILENAME, "w")
    total = ""

    for data, information in enumerate(inputFile):
        total += information
        print("{} {}".format(data, information))
        for dataMark in inputFile:
            dataMark = 0
            if "X" in inputFile:
                dataMark += 1
        print("{}".format(dataMark))

    userInput = str(input("Enter the number of a place to mark as visited"))

def saveFunction(inputFile, FILENAME):
    inputFile = FILENAME
    inputFile.close(FILENAME)

#MAIN FUNCTION
def main():
    choice = input(MENU).upper()
    print(data)
    while choice != "Q":
        if choice == "L":
            listFunction(data, FILENAME)
        elif choice == "A":
            addFunction(data,FILENAME)
        elif choice == "M":
            markFunction(data, FILENAME)
        else:
            print("Invalid menu choice")
        choice = input(MENU).upper()
    saveFunction(FILENAME)


def list_places(places):
    pass


main()





